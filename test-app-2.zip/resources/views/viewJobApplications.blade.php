@extends('layouts.app')

@section('content')
    <view-job-app />
    
@endsection

