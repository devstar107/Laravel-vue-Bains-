

<?php $__env->startSection('content'); ?>
    <view-job-app />
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PCF\Documents\test-app\resources\views/viewJobApplications.blade.php ENDPATH**/ ?>