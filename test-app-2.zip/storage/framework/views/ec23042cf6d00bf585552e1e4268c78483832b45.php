

<?php $__env->startSection('content'); ?>
    <job-app csrf_token="<?php echo e(csrf_token()); ?>" userdata="<?php echo e($user); ?>"/>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PCF\Documents\test-app\resources\views/jobApplication.blade.php ENDPATH**/ ?>